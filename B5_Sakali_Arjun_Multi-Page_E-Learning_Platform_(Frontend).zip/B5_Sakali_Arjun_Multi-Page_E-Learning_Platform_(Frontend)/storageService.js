function saveQuizScore(course, score){
    localStorage.setItem(course + "Score", score);
}

function getQuizScore(course){
    const score = localStorage.getItem(course + "Score");
    if(score === null){
        return 0;
    }
    return parseInt(score);
}

function saveCompletedCourse(course){
    let completedCourses = JSON.parse(localStorage.getItem("completedCourses"));
    if(!completedCourses){
        completedCourses = [];
    }
    if(!completedCourses.includes(course)){
        completedCourses.push(course);
    }
    localStorage.setItem("completedCourses", JSON.stringify(completedCourses));
}

function getCompletedCourses(){
    const completedCourses = JSON.parse(localStorage.getItem("completedCourses"));
    if(!completedCourses){
        return [];
    }
    return completedCourses;
}