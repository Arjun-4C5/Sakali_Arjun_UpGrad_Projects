const courses = [
    {
        id: 1,
        name: "HTML Fundamentals",
        lessons: [
            "Introduction to HTML",
            "HTML Document Structure",
            "Semantic HTML Elements",
            "Forms and Input Fields"
        ]
    },

    {
        id: 2,
        name: "CSS Layout Techniques",
        lessons: [
            "CSS Selectors",
            "Box Model",
            "Flexbox Layout",
            "CSS Grid Layout"
        ]
    },

    {
        id: 3,
        name: "JavaScript Programming",
        lessons: [
            "Variables and Data Types",
            "Functions and Scope",
            "DOM Manipulation",
            "Events and Event Handling"
        ]
    }
];


const quizData = {

    html: [
        {
            question: "What does HTML stand for?",
            options: [
                "Hyper Text Markup Language",
                "High Text Machine Language",
                "Hyper Tool Markup Language",
                "Home Tool Markup Language"
            ],
            answer: 0
        },

        {
            question: "Which HTML tag creates a hyperlink?",
            options: ["&lt;a&gt;", "&lt;link&gt;", "&lt;href&gt;", "&lt;url&gt;"],
            answer: 0
        },

        {
            question: "Which tag is used to display images?",
            options: ["&lt;img&gt;", "&lt;picture&gt;", "&lt;src&gt;", "&lt;image&gt;"],
            answer: 0
        },

        {
            question: "Which element defines the largest heading?",
            options: ["&lt;h6&gt;", "&lt;h1&gt;", "&lt;heading&gt;", "&lt;head&gt;"],
            answer: 1
        },

        {
            question: "Which attribute provides alternate text for images?",
            options: ["title", "alt", "src", "href"],
            answer: 1
        }
    ],



    css: [
        {
            question: "What does CSS stand for?",
            options: [
                "Creative Style Sheets",
                "Cascading Style Sheets",
                "Computer Style Sheets",
                "Colorful Style Sheets"
            ],
            answer: 1
        },

        {
            question: "Which property controls text size?",
            options: ["font-style", "font-size", "text-style", "size"],
            answer: 1
        },

        {
            question: "Which property controls spacing inside elements?",
            options: ["margin", "padding", "border", "spacing"],
            answer: 1
        },

        {
            question: "Which CSS layout uses rows and columns?",
            options: ["Flexbox", "Grid", "Float", "Inline"],
            answer: 1
        },

        {
            question: "Which symbol selects a class in CSS?",
            options: ["#", ".", "*", "&"],
            answer: 1
        }
    ],



    javascript: [
        {
            question: "Which keyword declares a variable?",
            options: ["var", "let", "const", "All of the above"],
            answer: 3
        },

        {
            question: "Which method selects element by ID?",
            options: [
                "getElementById()",
                "querySelectorAll()",
                "getElementsByClassName()",
                "selectById()"
            ],
            answer: 0
        },

        {
            question: "Which symbol is used for comments in JS?",
            options: ["//", "/* */", "#", "&lt;!-- --&gt;"],
            answer: 0
        },

        {
            question: "Which event occurs when user clicks?",
            options: ["onchange", "onclick", "onhover", "onsubmit"],
            answer: 1
        },

        {
            question: "Which keyword defines a function?",
            options: ["method", "function", "define", "func"],
            answer: 1
        }
    ]

};