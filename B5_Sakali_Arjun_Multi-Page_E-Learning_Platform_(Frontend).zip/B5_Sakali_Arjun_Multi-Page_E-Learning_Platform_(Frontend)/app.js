function initializeQuizPage() {

    const quizContainer = document.getElementById("quizContainer");

    if (!quizContainer) {
        return;
    }


    loadQuiz("html");

}


function initializeQuizSubmission() {

    const submitButton = document.getElementById("submitQuiz");

    if (!submitButton) {
        return;
    }

    submitButton.addEventListener("click", () => {
        submitQuiz();
    });

}

function initializeProfilePage() {

    const progressBar = document.getElementById("profileProgress");

    if (!progressBar) {
        return;
    }

    updateProfilePage();

}

function initializeDashboard() {

    const htmlCell = document.getElementById("htmlProgress");

    if (!htmlCell) {
        return;
    }

    updateDashboard();

}


function updateDashboard() {

    const htmlScore = getQuizScore("html");
    const cssScore = getQuizScore("css");
    const jsScore = getQuizScore("javascript");

    const avg = Math.round((htmlScore + cssScore + jsScore) / 3);

    const htmlCell = document.getElementById("htmlProgress");
    const cssCell = document.getElementById("cssProgress");
    const jsCell = document.getElementById("jsProgress");

    if (htmlCell) htmlCell.textContent = htmlScore + "%";
    if (cssCell) cssCell.textContent = cssScore + "%";
    if (jsCell) jsCell.textContent = jsScore + "%";


    const progressBar = document.getElementById("dashboardProgress");
    const overallText = document.getElementById("overallText");

    if (progressBar) progressBar.value = avg;

    if (overallText) overallText.textContent =
        "Overall course completion: " + avg + "%";

}


document.addEventListener("DOMContentLoaded", () => {

    initializeQuizPage();

    initializeQuizSubmission();

    initializeProfilePage();

    initializeDashboard();

});