const { calculatePercentage, checkPassFail, calculateGrade } = require("../js/quizService");


test("Percentage calculation should be correct", () => {

    expect(calculatePercentage(3,5)).toBe(60);

});


test("Score above 50 should return Pass", () => {

    expect(checkPassFail(75)).toBe("Pass");

});


test("Score below 50 should return Fail", () => {

    expect(checkPassFail(40)).toBe("Fail");

});


test("Score 85 should return Grade A", () => {

    expect(calculateGrade(85)).toBe("A");

});


test("Score 65 should return Grade B", () => {

    expect(calculateGrade(65)).toBe("B");

});