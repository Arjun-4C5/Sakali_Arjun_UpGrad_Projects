let currentCourse = "";
let currentQuestions = [];

function loadQuiz(course) {
    currentCourse = course;
    currentQuestions = quizData[course];
    const container = document.getElementById("quizContainer");
    container.innerHTML = "";
    currentQuestions.forEach((q, index) => {
        let questionHTML = `
            <div>
                <p><strong>Question ${index + 1}: ${q.question}</strong></p>
                ${q.options.map((option, i) => `
                    <label>
                        <input type="radio" name="q${index}" value="${i}">
                        ${option}
                    </label><br>
                `).join("")}
            </div>
            <br>
        `;
        container.innerHTML += questionHTML;
    });
}

function submitQuiz() {
    let score = 0;
    currentQuestions.forEach((q, index) => {
        const selected = document.querySelector(`input[name="q${index}"]:checked`);
        if (selected) {
            if (parseInt(selected.value) === q.answer) {
                score++;
            }
        }
    });
    const percentage = Math.round((score / currentQuestions.length) * 100);
    document.getElementById("quizResult").innerHTML = `<p><strong>Your ${currentCourse.toUpperCase()} Score: ${percentage}%</strong></p>`;
    saveQuizScore(currentCourse, percentage);
}

document.addEventListener("DOMContentLoaded", () => {
    const submitButton = document.getElementById("submitQuiz");
    if (submitButton) {
        submitButton.addEventListener("click", submitQuiz);
    }
});