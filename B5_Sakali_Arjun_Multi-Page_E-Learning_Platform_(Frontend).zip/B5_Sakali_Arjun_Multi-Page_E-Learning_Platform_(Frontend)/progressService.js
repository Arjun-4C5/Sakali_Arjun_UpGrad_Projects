function calculateAverage() {
    const htmlScore = getQuizScore("html");
    const cssScore = getQuizScore("css");
    const jsScore = getQuizScore("javascript");
    const average = Math.round((htmlScore + cssScore + jsScore) / 3);
    return average;
}
function updateProfilePage() {

    const scoreElement = document.getElementById("quizScore");
    const progressBar = document.getElementById("profileProgress");
    const completedList = document.getElementById("completedCourses");


    const htmlScore = getQuizScore("html");
    const cssScore = getQuizScore("css");
    const jsScore = getQuizScore("javascript");

    const avg = calculateAverage();


    if (scoreElement) {
        scoreElement.textContent =
            `HTML: ${htmlScore}% | CSS: ${cssScore}% | JS: ${jsScore}% | Average: ${avg}%`;
    }


    if (progressBar) {
        progressBar.value = avg;
    }


    if (completedList) {

        completedList.innerHTML = "";


        if (htmlScore === 100) {
            completedList.innerHTML += "<li>HTML Fundamentals</li>";
        }

        if (cssScore === 100) {
            completedList.innerHTML += "<li>CSS Layout Techniques</li>";
        }

        if (jsScore === 100) {
            completedList.innerHTML += "<li>JavaScript Programming</li>";
        }

        if (completedList.innerHTML === "") {
            completedList.innerHTML = "<li>No courses completed yet</li>";
        }

    }

}